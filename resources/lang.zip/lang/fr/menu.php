<?php
// fr
return [
    'companies' => 'Entreprises',
    'logs' => 'Journaux',
    'dashboard' => 'Tableau de bord',
    'reports' => 'Rapports',
    'users' => 'Utilisateurs',
    'feedback' => 'Retour',
    'settings' => 'Paramètres',
    '2fauth' => 'Authentification à deux facteurs',
    'logout' => 'Se déconnecter',
    'myconversations' => 'Mes conversations',
    'newconversations' => 'Nouvelle conversation',
    'changename' => 'Modifier le nom',
    'delete' => 'Supprimer',
    'noconversations' => 'Aucune conversation',
    'pinboard' => 'Tableau',
    'studio' => 'Studio'
];
