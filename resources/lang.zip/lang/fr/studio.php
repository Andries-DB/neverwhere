<?php

return [
    'select' => 'Sélectionnez la source',
    'suggestion_questions' => 'Questions de suggestion',
];
