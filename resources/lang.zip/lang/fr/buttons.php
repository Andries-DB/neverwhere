<?php
return [
    'add' => 'Ajouter',
    'delete' => 'Supprimer',
    'save' => 'Enregistrer',
    'edit' => 'Modifier',
];
