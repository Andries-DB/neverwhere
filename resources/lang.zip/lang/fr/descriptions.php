<?php
return [
    'select_users_to_see_sources' => 'Sélectionnez un groupe d’utilisateurs pour charger automatiquement les sources correspondantes',
    'logs' => 'Gérer les journaux de l’application',
    'reports' => 'Sélectionnez pour afficher un rapport',
    'users' => 'Gérer les utilisateurs et leur accès à la plateforme'
];
