<?php

return [
    'button' => 'Send',
    'delete' => 'Delete',
    'delete_loading' => 'Deleting...',
    'button_loading' => 'Sending...',
    'add' => 'Save',
    'create' => 'Create',
    'settings' => 'Submit your settings',
    'feedback' => 'Submit your feedback',
    'knowledge' => 'Submit your knowledge',
    'suggestion' => 'Submit your suggestion question',
    'refresh' => 'Submit your changes',
    'default' => 'Default',
    'width' => 'Width',
    'half' => 'Half',
    'full' => 'Full',
    'pin' => 'Pin',
    'pinning' => 'Pinning...'
];
