<?php
return [
    'select_users_to_see_sources' => 'Select a user group to automatically load the corresponding sources',
    'logs' => 'Manage the application logs',
    'reports' => 'Select to view a report',
    'users' => 'Manage users and their access to the platform'
];
