<?php

return [
    'select' => 'Select source',
    'suggestion_questions' => 'Suggestion questions',
];
