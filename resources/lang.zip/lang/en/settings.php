<?php
return [
    "decimal" => 'Decimal separator',
    'comma' => 'Comma',
    'point' => 'Point',
    'example' => 'Example',
    'thousand' => 'Thousand separator',
    'none' => 'None',
    'space' => 'Space',
    'errors' => 'Errors occurred',
    'success' => 'Settings saved successfully!',
    'nl' => 'Dutch',
    'fr' => 'French',
    'en' => 'English',
    'settings' => 'Settings',
    'settings_description' => 'Manage your personal preferences and account settings',
    'langandreg' => 'Language and Region',
];
