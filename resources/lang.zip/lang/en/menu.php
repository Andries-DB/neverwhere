<?php
// en
return [
    'companies' => 'Companies',
    'logs' => 'Logs',
    'dashboard' => 'Pinboard',
    'reports' => 'Reports',
    'users' => 'Users',
    'feedback' => 'Feedback',
    'settings' => 'Settings',
    '2fauth' => 'Two-Factor Authentication',
    'logout' => 'Logout',
    'myconversations' => 'My Conversations',
    'newconversations' => 'New Conversation',
    'changename' => 'Change Name',
    'delete' => 'Delete',
    'noconversations' => 'No conversations',
    'pinboard' => 'Pinboard',
    'studio' => 'Studio'
];
