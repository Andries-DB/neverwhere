<?php
return [
    'add' => 'Add',
    'delete' => 'Delete',
    'save' => 'Save',
    'edit' => 'Edit',
];
