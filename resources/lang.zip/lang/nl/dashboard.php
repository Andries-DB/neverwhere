<?php

return [
    'select' => 'Selecteer dashboard',
    'create' => 'Maak nieuw dashboard',
    'export' => 'Exporteer dashboard',
    'default' => 'Maak default',
    'delete' => 'Verwijder',
    'welcome' => 'Welkom op je dashboard! Hier kun je grafieken en tabellen toevoegen om snel inzicht te krijgen in je data. Begin met het vastpinnen van items via de conversatie.',
    'small' => 'Verklein',
    'big' => 'Vergroot',
    'refresh' => 'Refresh',
    'duplicate' => 'Dupliceer',
    'delete_pin' => 'Losmaken',
    'records' => 'records',
    'edit' => 'Titel bewerken'
];
