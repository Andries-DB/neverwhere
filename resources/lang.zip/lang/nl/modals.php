<?php

return [
    'button' => 'Verstuur',
    'delete' => 'Verwijder',
    'delete_loading' => 'Verwijderen...',
    'button_loading' => 'Versturen...',
    'add' => 'Opslaan',
    'create' => 'Maak aan',
    'settings' => 'Geef je instellingen door',
    'feedback' => 'Geef je feedback door',
    'knowledge' => 'Geef je knowledge door',
    'suggestion' => 'Geef je suggestievraag door',
    'refresh' => 'Geef je aanpassingen door',
    'default' => 'Standaard',
    'width' => 'Breedte',
    'half' => 'Halve',
    'full' => 'Volle',
    'pin' => 'Pin',
    'pinning' => 'Aan het pinnen...'
];
