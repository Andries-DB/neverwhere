<?php
return [
    "decimal" => 'Decimaal scheidingsteken',
    'comma' => 'Komma',
    'point' => 'Punt',
    'example' => 'Voorbeeld',
    'thousand' => 'Duizend scheidingsteken',
    'none' => 'Geen',
    'space' => 'Spatie',
    'errors' => 'Er zijn fouten opgetreden',
    'success' => 'Instellingen successvol opgeslagen!',
    'nl' => 'Nederlands',
    'fr' => 'Frans',
    'en' => 'Engels',
    'settings' => 'Instellingen',
    'settings_description' => 'Beheer je persoonlijke voorkeuren en account instellingen',
    'langandreg' => 'Taal en regio'


];
