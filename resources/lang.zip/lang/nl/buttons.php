<?php
return [
    'add' => 'Voeg toe',
    'delete' => 'Verwijder',
    'save' => 'Sla op',
    'edit' => 'Pas aan',
];
