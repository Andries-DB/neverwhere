<?php
return [
    'companies' => 'Bedrijven',
    'logs' => 'Logs',
    'dashboard' => 'Pinboard',
    'reports' => 'Rapporten',
    'users' => 'Gebruikers',
    'feedback' => 'Feedback',
    'settings' => 'Instellingen',
    '2fauth' => 'Tweestapsverificatie',
    'logout' => 'Uitloggen',
    'myconversations' => 'Mijn Conversaties',
    'newconversations' => "Nieuwe conversatie",
    'changename' => 'Pas naam aan',
    'delete' => 'Verwijderen',
    'noconversations' => 'Er zijn geen conversaties',
    'pinboard' => 'Pinboard',
    'studio' => 'Studio'
];
