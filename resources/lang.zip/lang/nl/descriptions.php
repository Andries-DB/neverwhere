<?php
return [
    'select_users_to_see_sources' => ' Selecteer een gebruikersgroep om automatisch de bijbehorende bronnen te laden',
    'logs' => 'Beheer de logs van de applicatie',
    'reports' => 'Selecteer om een rapport te bekijken',
    'users' => 'Beheer gebruikers en hun toegang tot het platform'

];
