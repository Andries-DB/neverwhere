<?php

return [
    'select' => 'Selecteer bron',
    'suggestion_questions' => 'Suggestie vragen',
];
