<?php
return [
    'select_users_to_see_sources' => 'Kies een gebruikersgroep. Databronnen zijn automatisch gekoppeld aan de gebruikersgroep.',
    'logs' => 'Neverwhere logboek',
    'reports' => 'Bekijk rapporten',
    'users' => 'Beheer gebruikers en hun toegang tot Neverwhere AI.'

];
