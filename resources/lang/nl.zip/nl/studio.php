<?php

return [
    'select' => 'Selecteer databron',
    'suggestion_questions' => 'Suggestie vragen',
    'dashboard' => 'Databronnen'
];
