<?php

return [
    'button' => 'Verstuur',
    'delete' => 'Verwijder',
    'delete_loading' => 'Verwijderen...',
    'button_loading' => 'Versturen...',
    'add' => 'Opslaan',
    'create' => 'Aanmaken',
    'settings' => 'Beheer je instellingen',
    'feedback' => 'Laat je feedback achter',
    'knowledge' => 'Train het model',
    'suggestion' => 'Geef nieuwe suggestievragen',
    'refresh' => 'Geef je aanpassingen door',
    'default' => 'Standaard',
    'width' => 'Breedte',
    'half' => 'Halve',
    'full' => 'Volle',
    'pin' => 'Pin',
    'pinning' => 'Aan het pinnen...',
    'create_new_dashboard' => 'Maak een nieuw pinboard aan',
    'new_dashboard' => 'Nieuw pinboard',
];
