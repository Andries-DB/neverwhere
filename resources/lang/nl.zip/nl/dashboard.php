<?php

return [
    'select' => 'Kies pinboard',
    'create' => 'Nieuw pinboard',
    'export' => 'Exporteer pinboard',
    'default' => 'Zet als standaard',
    'delete' => 'Verwijder',
    'welcome' => 'Verzamel de beste inzichten in je pinboards. Start een gesprek en voeg vervolgens tabellen en grafieken toe aan je pinboards.',
    'small' => 'Kleiner',
    'big' => 'Groter',
    'refresh' => 'Vernieuwen',
    'duplicate' => 'Dupliceer',
    'delete_pin' => 'Verwijder',
    'records' => 'Lijnen',
    'edit' => 'Titel bewerken',
    'change_name' => 'Verander kolom naam',
    'change_name_help' => 'Nieuwe kolomtitel.',
];
