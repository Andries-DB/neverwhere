<?php
return [
    'companies' => 'Bedrijven',
    'logs' => 'Logboek',
    'dashboard' => 'Pinboard',
    'reports' => 'Rapporten',
    'users' => 'Gebruikers',
    'feedback' => 'Feedback',
    'settings' => 'Instellingen',
    '2fauth' => 'Tweestapsverificatie',
    'logout' => 'Uitloggen',
    'myconversations' => 'Mijn gesprekken',
    'newconversations' => "Nieuw gesprek",
    'changename' => 'Naam wijzigen',
    'delete' => 'Verwijderen',
    'noconversations' => 'Er zijn geen gesprekken.',
    'pinboard' => 'Pinboard',
    'studio' => 'Dr. Itchy\'s labo'
];
