<?php
return [
    "decimal" => 'Decimaal scheidingsteken',
    'comma' => 'Komma',
    'point' => 'Punt',
    'example' => 'Voorbeeld',
    'thousand' => 'Duizendtal scheidingsteken',
    'none' => 'Geen',
    'space' => 'Spatie',
    'errors' => 'Oops. Er is iets misgelopen.',
    'success' => 'Instellingen successvol opgeslagen.',
    'nl' => 'Nederlands',
    'fr' => 'Frans',
    'en' => 'Engels',
    'settings' => 'Instellingen',
    'settings_description' => 'Beheer je persoonlijke voorkeuren.',
    'langandreg' => 'Taal'


];
