<?php
return [
    'add' => 'Toevoegen',
    'delete' => 'Verwijderen',
    'save' => 'Opslaan',
    'edit' => 'Aanpassen',
    'cancel' => 'Annuleren'
];
